#include "RTXLayer.hpp"

#include <fstream>

using namespace geode::prelude;

// Diagnostic log that is flushed immediately, independent of Geode's buffered
// logger, so the last completed step survives a driver crash.
static void rtxDebug(char const* message) {
    std::ofstream file("rtx-lite-debug.log", std::ios::app);
    if (file) {
        file << message << std::endl;
        file.flush();
    }
}

// GLSL 1.20 fragment shader. CCGLProgram automatically prepends the CC_*
// uniform declarations (matrices, time, random), so they are available here.
static const char* kRTXFragmentShader = R"(
varying vec4 v_fragmentColor;
varying vec2 v_texCoord;
uniform sampler2D CC_Texture0;

uniform vec2  u_texel;
uniform float u_bloomOn;
uniform float u_bloomIntensity;
uniform float u_bloomThreshold;
uniform float u_chroma;
uniform float u_vignette;
uniform float u_saturation;
uniform float u_contrast;
uniform float u_sharpen;
uniform float u_grain;

vec3 brightPass(vec2 uv) {
    vec3 c = texture2D(CC_Texture0, uv).rgb;
    float l = max(max(c.r, c.g), c.b);
    return c * smoothstep(u_bloomThreshold, 1.0, l);
}

void main() {
    vec2 uv = v_texCoord;

    // Chromatic aberration: shift red and blue away from the centre.
    vec2 dir = uv - vec2(0.5);
    float ca = u_chroma * 0.004;
    vec3 col;
    col.r = texture2D(CC_Texture0, uv + dir * ca).r;
    col.g = texture2D(CC_Texture0, uv).g;
    col.b = texture2D(CC_Texture0, uv - dir * ca).b;

    // Bloom: cheap 9-tap bright-pass blur.
    if (u_bloomOn > 0.5) {
        vec2 t = u_texel * 1.25;
        vec3 b = brightPass(uv) * 0.4;
        b += brightPass(uv + vec2( t.x,  0.0)) * 0.3;
        b += brightPass(uv + vec2(-t.x,  0.0)) * 0.3;
        b += brightPass(uv + vec2( 0.0,  t.y)) * 0.3;
        b += brightPass(uv + vec2( 0.0, -t.y)) * 0.3;
        b += brightPass(uv + vec2( t.x,  t.y)) * 0.2;
        b += brightPass(uv + vec2(-t.x,  t.y)) * 0.2;
        b += brightPass(uv + vec2( t.x, -t.y)) * 0.2;
        b += brightPass(uv + vec2(-t.x, -t.y)) * 0.2;
        col += (b / 2.4) * u_bloomIntensity;
    }

    // Contrast then saturation.
    col = (col - vec3(0.5)) * u_contrast + vec3(0.5);
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(lum), col, u_saturation);

    // Unsharp mask.
    if (u_sharpen > 0.001) {
        vec3 blur = texture2D(CC_Texture0, uv + vec2( u_texel.x, 0.0)).rgb
                  + texture2D(CC_Texture0, uv + vec2(-u_texel.x, 0.0)).rgb
                  + texture2D(CC_Texture0, uv + vec2(0.0,  u_texel.y)).rgb
                  + texture2D(CC_Texture0, uv + vec2(0.0, -u_texel.y)).rgb;
        blur *= 0.25;
        col += (col - blur) * u_sharpen;
    }

    // Vignette.
    float dist = length((uv - vec2(0.5)) * vec2(1.0, 0.9));
    float vig = 1.0 - smoothstep(0.35, 0.9, dist);
    col *= mix(1.0, vig, u_vignette);

    // Animated film grain.
    float n = fract(sin(dot(uv + CC_Time.x * 0.07, vec2(12.9898, 78.233))) * 43758.5453);
    col += (n - 0.5) * u_grain * 0.08;

    gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0) * v_fragmentColor;
}
)";

RTXLayer* RTXLayer::create() {
    auto ret = new RTXLayer();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool RTXLayer::init() {
    rtxDebug("init: begin");
    if (!CCNode::init()) {
        return false;
    }

    // The GL program is created lazily on the first visit, i.e. on the render
    // thread with a current OpenGL context. Compiling from setupHasCompleted
    // proved to be unreliable on some drivers.
    this->setID("rtx-lite-layer"_spr);
    rtxDebug("init: ready");
    return true;
}

void RTXLayer::refreshSettings() {
    auto mod = Mod::get();
    if (!mod) {
        return;
    }
    m_setEnabled = mod->getSettingValue<bool>("enabled");
    m_setBloom = mod->getSettingValue<bool>("bloom");
    m_setBloomIntensity = static_cast<float>(mod->getSettingValue<double>("bloom-intensity"));
    m_setBloomThreshold = static_cast<float>(mod->getSettingValue<double>("bloom-threshold"));
    m_setChroma = static_cast<float>(mod->getSettingValue<double>("chromatic"));
    m_setVignette = static_cast<float>(mod->getSettingValue<double>("vignette"));
    m_setSaturation = static_cast<float>(mod->getSettingValue<double>("saturation"));
    m_setContrast = static_cast<float>(mod->getSettingValue<double>("contrast"));
    m_setSharpen = static_cast<float>(mod->getSettingValue<double>("sharpen"));
    m_setGrain = static_cast<float>(mod->getSettingValue<double>("grain"));
}

bool RTXLayer::ensureProgram() {
    if (m_program) {
        return true;
    }
    if (m_programFailed) {
        return false;
    }

    // Raw GL step-by-step: the driver is crashing inside CCGLProgram, so we
    // bypass it and log every single call to find the exact one that dies.
    rtxDebug("ensureProgram: glCreateProgram");
    GLuint program = glCreateProgram();
    rtxDebug("ensureProgram: glCreateShader(vertex)");
    GLuint vs = glCreateShader(GL_VERTEX_SHADER);
    // Use our own vertex shader source: strlen() crashed on the cocos static
    // pointer inside the game, so we don't touch it at all.
    static const char* kCCPrelude =
        "uniform mat4 CC_PMatrix;\n"
        "uniform mat4 CC_MVMatrix;\n"
        "uniform mat4 CC_MVPMatrix;\n"
        "uniform vec4 CC_Time;\n"
        "uniform vec4 CC_SinTime;\n"
        "uniform vec4 CC_CosTime;\n"
        "uniform vec4 CC_Random01;\n";
    static const char* kRTXVertexShader =
        "attribute vec4 a_position;\n"
        "attribute vec2 a_texCoord;\n"
        "attribute vec4 a_color;\n"
        "varying vec4 v_fragmentColor;\n"
        "varying vec2 v_texCoord;\n"
        "void main() {\n"
        "    gl_Position = CC_MVPMatrix * a_position;\n"
        "    v_fragmentColor = a_color;\n"
        "    v_texCoord = a_texCoord;\n"
        "}\n";
    const GLchar* vsSources[] = { kCCPrelude, kRTXVertexShader };
    rtxDebug("ensureProgram: glShaderSource(vertex)");
    glShaderSource(vs, 2, vsSources, nullptr);
    rtxDebug("ensureProgram: glCompileShader(vertex)");
    glCompileShader(vs);
    rtxDebug("ensureProgram: glGetShaderiv(vertex)");
    GLint vsOk = 0;
    glGetShaderiv(vs, GL_COMPILE_STATUS, &vsOk);
    if (!vsOk) {
        char buf[2048];
        GLsizei len = 0;
        glGetShaderInfoLog(vs, sizeof(buf) - 1, &len, buf);
        buf[len] = '\0';
        rtxDebug(buf);
        rtxDebug("ensureProgram: vertex shader compile FAILED");
        log::error("RTX Lite: vertex shader compile failed; effect disabled");
        m_programFailed = true;
        return false;
    }
    rtxDebug("ensureProgram: glCreateShader(fragment)");
    GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
    rtxDebug("ensureProgram: glShaderSource(fragment)");
    const GLchar* fsSources[] = { kCCPrelude, kRTXFragmentShader };
    glShaderSource(fs, 2, fsSources, nullptr);
    rtxDebug("ensureProgram: glCompileShader(fragment)");
    glCompileShader(fs);
    rtxDebug("ensureProgram: glGetShaderiv(fragment)");
    GLint fsOk = 0;
    glGetShaderiv(fs, GL_COMPILE_STATUS, &fsOk);
    if (!fsOk) {
        char buf[2048];
        GLsizei len = 0;
        glGetShaderInfoLog(fs, sizeof(buf) - 1, &len, buf);
        buf[len] = '\0';
        rtxDebug(buf);
        rtxDebug("ensureProgram: fragment shader compile FAILED");
        log::error("RTX Lite: fragment shader compile failed; effect disabled");
        m_programFailed = true;
        return false;
    }
    rtxDebug("ensureProgram: glAttachShader");
    glAttachShader(program, vs);
    glAttachShader(program, fs);
    glBindAttribLocation(program, kCCVertexAttrib_Position, kCCAttributeNamePosition);
    glBindAttribLocation(program, kCCVertexAttrib_Color, kCCAttributeNameColor);
    glBindAttribLocation(program, kCCVertexAttrib_TexCoords, kCCAttributeNameTexCoord);
    rtxDebug("ensureProgram: glLinkProgram");
    glLinkProgram(program);
    rtxDebug("ensureProgram: glGetProgramiv(link)");
    GLint linked = 0;
    glGetProgramiv(program, GL_LINK_STATUS, &linked);
    if (!linked) {
        rtxDebug("ensureProgram: program link FAILED");
        log::error("RTX Lite: shader link failed; effect disabled");
        m_programFailed = true;
        return false;
    }
    rtxDebug("ensureProgram: program linked");

    // Wrap the raw program in a CCGLProgram so the rest of the pipeline
    // (use()/uniform helpers) keeps working without recompiling.
    m_program = new CCGLProgram();
    m_program->m_uProgram = program;
    m_program->m_uVertShader = vs;
    m_program->m_uFragShader = fs;
    m_program->updateUniforms();

    m_uMVP = m_program->getUniformLocationForName(kCCUniformMVPMatrix_s);
    m_uTime = m_program->getUniformLocationForName(kCCUniformTime_s);
    m_uSampler = m_program->getUniformLocationForName(kCCUniformSampler_s);
    m_uTexel = m_program->getUniformLocationForName("u_texel");
    m_uBloomOn = m_program->getUniformLocationForName("u_bloomOn");
    m_uBloomIntensity = m_program->getUniformLocationForName("u_bloomIntensity");
    m_uBloomThreshold = m_program->getUniformLocationForName("u_bloomThreshold");
    m_uChroma = m_program->getUniformLocationForName("u_chroma");
    m_uVignette = m_program->getUniformLocationForName("u_vignette");
    m_uSaturation = m_program->getUniformLocationForName("u_saturation");
    m_uContrast = m_program->getUniformLocationForName("u_contrast");
    m_uSharpen = m_program->getUniformLocationForName("u_sharpen");
    m_uGrain = m_program->getUniformLocationForName("u_grain");

    if (m_uMVP < 0 || m_uTexel < 0 || m_uBloomIntensity < 0) {
        rtxDebug("ensureProgram: link FAILED (missing uniforms)");
        log::error("RTX Lite: fragment shader failed to link; effect disabled");
        m_program->release();
        m_program = nullptr;
        m_programFailed = true;
        return false;
    }
    log::info("RTX Lite: shader linked, overlay ready");
    rtxDebug("ensureProgram: ready");
    return true;
}

RTXLayer::~RTXLayer() {
    if (m_texture) {
        m_texture->release();
        m_texture = nullptr;
    }
    if (m_program) {
        m_program->release();
        m_program = nullptr;
    }
}

void RTXLayer::ensureTexture(unsigned int width, unsigned int height) {
    if (m_texture && m_texWidth == width && m_texHeight == height) {
        return;
    }

    if (m_texture) {
        m_texture->release();
        m_texture = nullptr;
    }

    m_texWidth = width;
    m_texHeight = height;

    m_texture = new CCTexture2D();
    m_texture->initWithData(
        nullptr,
        kCCTexture2DPixelFormat_RGBA8888,
        m_texWidth,
        m_texHeight,
        CCSize(static_cast<float>(m_texWidth), static_cast<float>(m_texHeight))
    );

    ccTexParams params = { GL_LINEAR, GL_LINEAR, GL_CLAMP_TO_EDGE, GL_CLAMP_TO_EDGE };
    m_texture->setTexParameters(&params);

    log::info("RTX Lite: capture texture {}x{}", m_texWidth, m_texHeight);
    rtxDebug("ensureTexture: allocated");
}

void RTXLayer::visit() {
    auto mod = Mod::get();
    if (!mod) {
        CCNode::visit();
        return;
    }

    // Refresh the cached settings twice per second instead of every frame.
    auto director = CCDirector::sharedDirector();
    float now = static_cast<float>(director->getTotalFrames() * director->getAnimationInterval());
    if (now >= m_nextSettingsRefresh) {
        m_nextSettingsRefresh = now + 0.5f;
        this->refreshSettings();
    }

    if (!m_setEnabled) {
        // Draw nothing: the framebuffer already contains the untouched scene.
        return;
    }

    if (!this->ensureProgram()) {
        CCNode::visit();
        return;
    }

    if (!m_loggedFirstFrame) {
        rtxDebug("visit: enter");
    }

    auto view = CCEGLView::sharedOpenGLView();
    if (!view) {
        CCNode::visit();
        return;
    }

    auto frame = view->getFrameSize();
    int frameWidth = static_cast<int>(frame.width);
    int frameHeight = static_cast<int>(frame.height);
    if (frameWidth <= 0 || frameHeight <= 0) {
        CCNode::visit();
        return;
    }

    // Capture the current viewport, clamped to the framebuffer. This never
    // reads outside the window even if the design-resolution policy makes the
    // viewport larger than (or offset from) the window.
    GLint vp[4] = { 0, 0, frameWidth, frameHeight };
    glGetIntegerv(GL_VIEWPORT, vp);

    int x0 = std::max(0, vp[0]);
    int y0 = std::max(0, vp[1]);
    int x1 = std::min(frameWidth, vp[0] + vp[2]);
    int y1 = std::min(frameHeight, vp[1] + vp[3]);
    if (x1 <= x0 || y1 <= y0) {
        x0 = 0;
        y0 = 0;
        x1 = frameWidth;
        y1 = frameHeight;
    }

    unsigned int width = static_cast<unsigned int>(x1 - x0);
    unsigned int height = static_cast<unsigned int>(y1 - y0);

    this->ensureTexture(width, height);
    if (!m_texture || m_texture->getName() == 0) {
        CCNode::visit();
        return;
    }

    if (!m_loggedFirstFrame) {
        m_loggedFirstFrame = true;
        log::info("RTX Lite: first frame: frame {}x{}, viewport {}x{} at {},{} -> capture {}x{}",
            frameWidth, frameHeight, vp[2], vp[3], vp[0], vp[1], width, height);
        rtxDebug("visit: first frame");
    }

    // Save the GL state that this raw draw may disturb.
    GLboolean scissorWasOn = glIsEnabled(GL_SCISSOR_TEST);
    GLboolean blendWasOn = glIsEnabled(GL_BLEND);
    GLboolean depthWasOn = glIsEnabled(GL_DEPTH_TEST);
    GLboolean cullWasOn = glIsEnabled(GL_CULL_FACE);
    GLint prevBlendSrc = GL_ONE;
    GLint prevBlendDst = GL_ZERO;
    glGetIntegerv(GL_BLEND_SRC, &prevBlendSrc);
    glGetIntegerv(GL_BLEND_DST, &prevBlendDst);
    GLint prevVBO = 0;
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &prevVBO);

    // Scissor would clip both the copy and the fullscreen quad.
    if (scissorWasOn) {
        glDisable(GL_SCISSOR_TEST);
    }

    // Copy the viewport region into our texture. glCopyTexSubImage2D reads
    // framebuffer row 0 = bottom of the screen, which matches v = 0 below.
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, m_texture->getName());
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, x0, y0, m_texWidth, m_texHeight);

    // Upload the effect parameters.
    m_program->use();

    // Identity MVP: the quad is already in normalized device coordinates.
    static GLfloat identity[16] = {
        1.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f,
    };
    m_program->setUniformLocationWithMatrix4fv(m_uMVP, identity, 1);

    // CC_Time mirrors what cocos would upload via setUniformsForBuiltins().
    float time = static_cast<float>(director->getTotalFrames() * director->getAnimationInterval());
    m_program->setUniformLocationWith4f(m_uTime, time / 10.0f, time, time * 2.0f, time * 4.0f);
    m_program->setUniformLocationWith1i(m_uSampler, 0);

    m_program->setUniformLocationWith2f(m_uTexel, 1.0f / m_texWidth, 1.0f / m_texHeight);
    m_program->setUniformLocationWith1f(m_uBloomOn, m_setBloom ? 1.0f : 0.0f);
    m_program->setUniformLocationWith1f(m_uBloomIntensity, m_setBloomIntensity);
    m_program->setUniformLocationWith1f(m_uBloomThreshold, m_setBloomThreshold);
    m_program->setUniformLocationWith1f(m_uChroma, m_setChroma);
    m_program->setUniformLocationWith1f(m_uVignette, m_setVignette);
    m_program->setUniformLocationWith1f(m_uSaturation, m_setSaturation);
    m_program->setUniformLocationWith1f(m_uContrast, m_setContrast);
    m_program->setUniformLocationWith1f(m_uSharpen, m_setSharpen);
    m_program->setUniformLocationWith1f(m_uGrain, m_setGrain);

    // Fullscreen triangle strip in clip space, matching the captured viewport.
    float nx0 = static_cast<float>(x0) / frameWidth * 2.0f - 1.0f;
    float ny0 = static_cast<float>(y0) / frameHeight * 2.0f - 1.0f;
    float nx1 = static_cast<float>(x1) / frameWidth * 2.0f - 1.0f;
    float ny1 = static_cast<float>(y1) / frameHeight * 2.0f - 1.0f;

    GLfloat quadPositions[8] = {
        nx0, ny0,
        nx1, ny0,
        nx0, ny1,
        nx1, ny1,
    };
    static GLfloat quadTexCoords[8] = {
        0.0f, 0.0f,
        1.0f, 0.0f,
        0.0f, 1.0f,
        1.0f, 1.0f,
    };
    static GLfloat quadColors[16] = {
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f, 1.0f,
    };

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    ccGLBlendFunc(GL_ONE, GL_ZERO);
    ccGLBindTexture2D(m_texture->getName());

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    ccGLEnableVertexAttribs(kCCVertexAttribFlag_PosColorTex);
    glVertexAttribPointer(kCCVertexAttrib_Position, 2, GL_FLOAT, GL_FALSE, 0, quadPositions);
    glVertexAttribPointer(kCCVertexAttrib_TexCoords, 2, GL_FLOAT, GL_FALSE, 0, quadTexCoords);
    glVertexAttribPointer(kCCVertexAttrib_Color, 4, GL_FLOAT, GL_FALSE, 0, quadColors);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    ccGLEnableVertexAttribs(kCCVertexAttribFlag_None);

    // Restore the state we changed.
    glBindBuffer(GL_ARRAY_BUFFER, static_cast<GLuint>(prevVBO));
    ccGLBlendFunc(static_cast<GLenum>(prevBlendSrc), static_cast<GLenum>(prevBlendDst));
    if (!blendWasOn) {
        glDisable(GL_BLEND);
    }
    if (depthWasOn) {
        glEnable(GL_DEPTH_TEST);
    }
    if (cullWasOn) {
        glEnable(GL_CULL_FACE);
    }
    if (scissorWasOn) {
        glEnable(GL_SCISSOR_TEST);
    }

    CCNode::visit();
}
