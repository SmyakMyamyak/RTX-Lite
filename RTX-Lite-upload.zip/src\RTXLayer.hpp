#pragma once

#include <Geode/Geode.hpp>

// Fullscreen post-processing overlay.
//
// It is added as the last (highest z-order) child of PlayLayer. When the scene
// visits it, the current backbuffer already contains everything that has been
// drawn this frame, so we copy it into a texture and draw it back through a
// custom fragment shader that applies the "RTX" look.
//
// The draw is done with a raw clip-space quad and an identity MVP matrix. That
// keeps the effect independent of the design resolution, letterboxing and
// texture-flip conventions used by the sprite hierarchy.
class RTXLayer : public cocos2d::CCNode {
public:
    static RTXLayer* create();

    bool init() override;
    void visit() override;

    ~RTXLayer() override;

private:
    bool ensureProgram();
    void ensureTexture(unsigned int width, unsigned int height);
    void refreshSettings();

    cocos2d::CCGLProgram* m_program = nullptr;
    cocos2d::CCTexture2D* m_texture = nullptr;
    bool m_programFailed = false;

    unsigned int m_texWidth = 0;
    unsigned int m_texHeight = 0;
    bool m_loggedFirstFrame = false;

    // Cached uniform locations.
    GLint m_uMVP = -1;
    GLint m_uTime = -1;
    GLint m_uSampler = -1;
    GLint m_uTexel = -1;
    GLint m_uBloomOn = -1;
    GLint m_uBloomIntensity = -1;
    GLint m_uBloomThreshold = -1;
    GLint m_uChroma = -1;
    GLint m_uVignette = -1;
    GLint m_uSaturation = -1;
    GLint m_uContrast = -1;
    GLint m_uSharpen = -1;
    GLint m_uGrain = -1;

    // Settings cache: avoids hitting Mod::getSettingValue every frame.
    bool m_setEnabled = true;
    bool m_setBloom = true;
    float m_setBloomIntensity = 0.8f;
    float m_setBloomThreshold = 0.7f;
    float m_setChroma = 0.5f;
    float m_setVignette = 0.35f;
    float m_setSaturation = 1.1f;
    float m_setContrast = 1.08f;
    float m_setSharpen = 0.35f;
    float m_setGrain = 0.3f;
    float m_nextSettingsRefresh = 0.0f;
};
