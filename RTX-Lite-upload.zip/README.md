# RTX Lite

Cinematic RTX-style post-processing for Geometry Dash that runs on any GPU — no RTX card needed.

Features: bloom, saturation/contrast grading, vignette, chromatic aberration, sharpening and animated film grain. All settings are configurable in-game via the Geode mod settings page.

Built with [Geode](https://geode-sdk.org) for Geometry Dash 2.2081.
