#include <Geode/modify/PlayLayer.hpp>

#include "RTXLayer.hpp"

using namespace geode::prelude;

class $modify(RTXPlayLayer, PlayLayer) {
    struct Fields {
        RTXLayer* overlay = nullptr;
    };

    void setupHasCompleted() {
        PlayLayer::setupHasCompleted();

        if (!m_fields->overlay) {
            m_fields->overlay = RTXLayer::create();
            if (m_fields->overlay) {
                this->addChild(m_fields->overlay, 100000);
            }
        }
    }
};

$on_mod(Loaded) {
    log::info("RTX Lite loaded");
}
