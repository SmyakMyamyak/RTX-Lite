# RTX Lite

Cinematic RTX-style post-processing for Geometry Dash that runs on **any GPU** — no RTX card needed. The mod captures the frame each tick and draws it back through a lightweight overlay shader, giving levels a filmic, modern look.

## Effects

- **Bloom** — soft glow around bright objects, with adjustable intensity and threshold
- **Color grading** — saturation and contrast controls
- **Vignette** — gently darkened screen edges
- **Chromatic aberration** — subtle colour fringing near the edges
- **Sharpening** — crisp edges via an unsharp mask
- **Film grain** — fine animated noise for a cinematic feel

All effects can be toggled and tuned in the mod settings and are applied only while playing a level.

## Performance

The whole effect is a single fullscreen pass with a hand-rolled shader, so even a GTX-class card handles it smoothly at 60+ FPS.

---

Made by **N1Urban**
